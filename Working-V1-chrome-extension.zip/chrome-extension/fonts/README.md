# Bundled Fonts

For air-gap compliance (HC-07) the extension loads fonts locally — there are **no
CDN calls at runtime**. The two files in this folder are referenced by every
extension page via `@font-face`:

- `PlayfairDisplay.woff2` — headings (serif)
- `Montserrat.woff2` — body / UI (sans-serif)

## About these files

The two `.woff2` files shipped here are **valid but minimal placeholder fonts**.
They load without console errors and satisfy the air-gap requirement, but they do
not contain the full Playfair Display / Montserrat glyph sets. Every stylesheet in
this project lists a system fallback (`serif` / `sans-serif` / `system-ui`), so the
UI renders correctly out of the box.

## Installing the real typefaces (recommended for production)

To get the intended typography, replace both files with the official webfonts:

1. Download from Google Fonts (on a networked machine):
   - https://fonts.google.com/specimen/Playfair+Display
   - https://fonts.google.com/specimen/Montserrat
2. Convert the `.ttf` to `.woff2` if needed (e.g. with `fonttools`:
   `pip install fonttools brotli` then
   `fonttools ttLib.woff2 compress PlayfairDisplay-Regular.ttf`).
3. Drop the resulting files in this folder using these **exact filenames**:
   - `PlayfairDisplay.woff2`
   - `Montserrat.woff2`

No code changes are required — the `@font-face` `src` paths already point here.
