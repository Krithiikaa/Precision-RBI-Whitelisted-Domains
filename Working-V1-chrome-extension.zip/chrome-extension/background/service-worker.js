/* ============================================================================
 * Precision RBI — background service worker (Manifest V3)
 * ----------------------------------------------------------------------------
 * Intercepts navigation to whitelisted domains, starts a server-side isolated
 * session, and swaps the tab to the Canvas viewer. Non-whitelisted navigation
 * is never touched. Keep-alive via chrome.alarms. Teardown via tabs.onRemoved.
 * ==========================================================================*/

// ── [SECTION 3] Hardcoded whitelist ────────────────────────────────────────
const RBI_WHITELIST = [
  'precisionit.co.in', 'www.precisionit.co.in',
  'innait.com', 'www.innait.com', 'prism.precisionit.co.in',
  'mail.google.com', 'drive.google.com', 'www.youtube.com', 'youtube.com',
  'sheets.google.com', 'docs.google.com', 'calendar.google.com',
  'slides.google.com', 'forms.google.com', 'meet.google.com',
  'chat.google.com', 'keep.google.com', 'sites.google.com',
  'jamboard.google.com', 'classroom.google.com', 'contacts.google.com',
  'photos.google.com', 'voice.google.com', 'maps.google.com',
  'news.google.com', 'accounts.google.com', 'workspace.google.com',
  'admin.google.com', 'innaitdemo.innait.com'
];
const WHITELIST_SET = new Set(RBI_WHITELIST);

// [MATCHING RULE] exact hostname OR endsWith('.google.com')
function matchesWhitelist(hostname) {
  if (!hostname) return false;
  if (WHITELIST_SET.has(hostname)) return true;
  if (hostname === 'google.com' || hostname.endsWith('.google.com')) return true;
  return false;
}

// ── In-memory state (rehydrated from chrome.storage.session) ───────────────
// tabId -> { sessionId, renderWsUrl, domain, streamMode, startedAt }
let activeSessions = new Map();
let serverUrl = null;
let enabled = true;
let userId = null;

async function loadState() {
  const sync = await chrome.storage.sync.get(['serverUrl', 'enabled', 'userId', 'streamModePref']);
  serverUrl = sync.serverUrl || null;
  enabled = sync.enabled !== false; // default on
  userId = sync.userId;
  if (!userId) {
    userId = 'u_' + Math.random().toString(36).slice(2, 11);
    await chrome.storage.sync.set({ userId });
  }
  const sess = await chrome.storage.session.get(['activeSessions']);
  if (sess.activeSessions) {
    activeSessions = new Map(Object.entries(sess.activeSessions).map(([k, v]) => [Number(k), v]));
  }
}

async function persistSessions() {
  const obj = {};
  for (const [tabId, s] of activeSessions.entries()) obj[tabId] = s;
  await chrome.storage.session.set({ activeSessions: obj });
}

function apiBase() {
  // serverUrl like http://10.225.244.10 ; API + render go through nginx :443.
  if (!serverUrl) return null;
  return serverUrl.replace(/\/+$/, '');
}

// ── Backoff helper ──────────────────────────────────────────────────────────
async function fetchWithBackoff(url, opts, maxRetries = 5) {
  let delay = 1000;
  for (let i = 0; i <= maxRetries; i++) {
    try {
      const r = await fetch(url, opts);
      return r;
    } catch (e) {
      if (i === maxRetries) throw e;
      await new Promise((res) => setTimeout(res, delay));
      delay = Math.min(delay * 2, 30000);
    }
  }
}

// ── Start an isolated session for a tab ─────────────────────────────────────
async function startIsolation(tabId, targetUrl, domain) {
  const base = apiBase();
  if (!base) return;

  // [STEP B] Reuse existing session for this user if one is open in any tab.
  for (const [, s] of activeSessions.entries()) {
    if (s.userId === userId && s.sessionId) {
      // Reuse: jump straight to viewer with the same session.
      const viewer = chrome.runtime.getURL('rbi-viewer/viewer.html') +
        `?renderWsUrl=${encodeURIComponent(s.renderWsUrl)}` +
        `&sessionId=${encodeURIComponent(s.sessionId)}` +
        `&url=${encodeURIComponent(targetUrl)}` +
        `&streamMode=${encodeURIComponent(s.streamMode || 'canvas')}`;
      activeSessions.set(tabId, { ...s, domain, tabId });
      await persistSessions();
      await chrome.tabs.update(tabId, { url: viewer });
      return;
    }
  }

  // [STEP A] Show loading page immediately (preempts the original navigation).
  const loadingUrl = chrome.runtime.getURL('loading/loading.html') +
    `?domain=${encodeURIComponent(domain)}`;
  await chrome.tabs.update(tabId, { url: loadingUrl });

  try {
    const resp = await fetchWithBackoff(`${base}/api/start-session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, userIp: '', targetUrl }),
    });

    if (resp.status === 503) {
      const capUrl = chrome.runtime.getURL('loading/loading.html') +
        `?domain=${encodeURIComponent(domain)}&error=capacity`;
      await chrome.tabs.update(tabId, { url: capUrl });
      return;
    }
    if (!resp.ok) {
      const errUrl = chrome.runtime.getURL('loading/loading.html') +
        `?domain=${encodeURIComponent(domain)}&error=server`;
      await chrome.tabs.update(tabId, { url: errUrl });
      return;
    }

    const data = await resp.json();
    const { sessionId, renderWsUrl, streamMode } = data;

    const session = { sessionId, renderWsUrl, streamMode, domain, userId, startedAt: Date.now(), tabId };
    activeSessions.set(tabId, session);
    await persistSessions();

    const viewer = chrome.runtime.getURL('rbi-viewer/viewer.html') +
      `?renderWsUrl=${encodeURIComponent(renderWsUrl)}` +
      `&sessionId=${encodeURIComponent(sessionId)}` +
      `&url=${encodeURIComponent(targetUrl)}` +
      `&streamMode=${encodeURIComponent(streamMode || 'canvas')}`;
    await chrome.tabs.update(tabId, { url: viewer });
  } catch (e) {
    const errUrl = chrome.runtime.getURL('loading/loading.html') +
      `?domain=${encodeURIComponent(domain)}&error=connect`;
    try { await chrome.tabs.update(tabId, { url: errUrl }); } catch (_) {}
  }
}

// ── Navigation interception ─────────────────────────────────────────────────
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return;        // main frame only
  await loadState();
  if (!enabled || !serverUrl) return;

  let hostname;
  try { hostname = new URL(details.url).hostname; } catch (_) { return; }
  if (!matchesWhitelist(hostname)) return;  // [EXT-01] no match → do nothing

  // Already inside a viewer/loading page? skip.
  if (details.url.startsWith('chrome-extension://')) return;

  startIsolation(details.tabId, details.url, hostname);
});

// ── Teardown PATH 1: tab removed ────────────────────────────────────────────
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const s = activeSessions.get(tabId);
  if (!s) return;
  activeSessions.delete(tabId);
  await persistSessions();
  const base = apiBase();
  if (!base) return;
  // Only end the session if no other tab uses it (multi-tab reuse).
  const stillUsed = [...activeSessions.values()].some((x) => x.sessionId === s.sessionId);
  if (stillUsed) return;
  try {
    await fetch(`${base}/api/end-session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId: s.sessionId }),
    });
  } catch (_) {}
});

// ── Keep-alive PATH 2: heartbeat alarm ──────────────────────────────────────
chrome.alarms.create('heartbeat', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'heartbeat') return;
  await loadState();
  const base = apiBase();
  if (!base) return;
  const sent = new Set();
  for (const s of activeSessions.values()) {
    if (sent.has(s.sessionId)) continue;
    sent.add(s.sessionId);
    try {
      await fetch(`${base}/api/heartbeat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: s.sessionId }),
      });
    } catch (_) {}
  }
});

// ── Messages from popup / viewer ────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    await loadState();
    if (msg.type === 'GET_STATE') {
      sendResponse({
        enabled, serverUrl, userId,
        sessions: [...activeSessions.values()],
      });
    } else if (msg.type === 'TOGGLE_ENABLED') {
      enabled = !!msg.enabled;
      await chrome.storage.sync.set({ enabled });
      sendResponse({ enabled });
    } else if (msg.type === 'OPEN_CURRENT_IN_RBI') {
      // Manual trigger for any URL.
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url) {
        let host = '';
        try { host = new URL(tab.url).hostname; } catch (_) {}
        startIsolation(tab.id, tab.url, host || 'page');
      }
      sendResponse({ ok: true });
    } else if (msg.type === 'CLOSE_SESSION') {
      const base = apiBase();
      if (base && msg.sessionId) {
        try {
          await fetch(`${base}/api/end-session`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sessionId: msg.sessionId }),
          });
        } catch (_) {}
      }
      for (const [tabId, s] of activeSessions.entries()) {
        if (s.sessionId === msg.sessionId) { activeSessions.delete(tabId); try { await chrome.tabs.remove(tabId); } catch (_) {} }
      }
      await persistSessions();
      sendResponse({ ok: true });
    } else if (msg.type === 'SESSION_READY_POLL') {
      // loading.html polls here to learn the viewer URL once ready.
      const s = [...activeSessions.values()].find((x) => x.domain === msg.domain);
      sendResponse({ session: s || null });
    }
  })();
  return true; // async
});

// ── onInstalled: prompt for server config if unset ──────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  await loadState();
  if (!serverUrl) {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#D85A30' });
  }
});

// Initial load.
loadState();
